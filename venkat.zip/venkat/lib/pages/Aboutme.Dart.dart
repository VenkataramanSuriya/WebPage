import 'package:flutter/material.dart';
class Aboutme extends StatelessWidget {
  const Aboutme({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 300,
              width: 300,
              decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                      image: AssetImage("Assets/Suriya.jpg")
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.blueGrey,
                      offset: Offset(0, 0),
                      blurRadius: 6,
                      spreadRadius: 6,
                    )
                  ]
              ),
            ),
            const SizedBox(width: 46,),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Developer\nData Scientist\nIOT Guy",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.bold,
                    color: Colors.black
                  ),
                ),
                const SizedBox(height: 20,),
                Text(""" 
                Hi This Is Venkat Raman,
                Currently Persuing,
                BCA Data Science II Year.
                """,
                textAlign: TextAlign.right,
                style: TextStyle(
                  fontSize: 22,
                  color: Colors.black

                ),)
              ],
            )
          ],
        ),
      ),
    );
  }
}
